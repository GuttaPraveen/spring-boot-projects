package com.trio.praveen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaMappingUsingOneToMany2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaMappingUsingOneToMany2Application.class, args);
	}

}
