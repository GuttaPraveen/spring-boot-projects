package com.exampleJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleJpaApplication.class, args);
	}

}
