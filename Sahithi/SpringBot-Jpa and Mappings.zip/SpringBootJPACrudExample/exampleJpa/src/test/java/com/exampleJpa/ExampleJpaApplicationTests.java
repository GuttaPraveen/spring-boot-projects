package com.exampleJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
