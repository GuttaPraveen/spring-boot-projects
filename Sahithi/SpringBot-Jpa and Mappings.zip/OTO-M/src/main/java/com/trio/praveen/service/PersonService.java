package com.trio.praveen.service;

import org.springframework.stereotype.Service;

@Service
public interface PersonService
{

	void saveData();

}
