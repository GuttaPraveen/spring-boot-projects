package com.trio.praveen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trio.praveen.entity.Bank;
import com.trio.praveen.repository.AccountRepository;
import com.trio.praveen.repository.BankRepository;
import com.trio.praveen.request.MoneyRequest;

@RestController
@RequestMapping("/api")
public class MoneyController
{
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private BankRepository bankRepository;
	
	@PostMapping("/save")
	public Bank save(@RequestBody MoneyRequest moneyRequest)
	{
		return bankRepository.save(moneyRequest.getBank());
	}
	
	@GetMapping("/get")
	public List<Bank> get()
	{
		return bankRepository.findAll();
	}
	
}
