package com.trio.praveen.request;

import com.trio.praveen.entity.Bank;

public class MoneyRequest 
{
	private Bank bank;

	public Bank getBank()
	{
		return bank;
	}

	public void setBank(Bank bank) 
	{
		this.bank = bank;
	}
	
	
}
