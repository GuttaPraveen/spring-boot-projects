package com.trio.praveen.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
@Entity
public class Employee
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String name;
	private String emailId;
	private String mobNo;
	private String design;
	
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="addrs_id",referencedColumnName = "id")
	private Address address;
	/*
	   @OneToOne(mappedBy = “address”): Establishes a bidirectional one-to-one relationship with Employee.
	   The “mappedBy” attribute refers to the field in the owning entity (Employee) that maps this relationship.
	 
	   cascade = CascadeType.ALL: Specifies that all operations (e.g., persist, remove) should be cascaded to the associated Stock. For instance, if you save/update/delete a Employee, it will also affect the associated Address.

	   fetch = FetchType.EAGER: Specifies that the associated Address should be fetched eagerly (loaded immediately) whenever a Employee is fetched.

	   @JoinColumn: Specifies the foreign key column in the Employee table that references the AdressId column in the Address table.
	*/
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getDesign() {
		return design;
	}
	public void setDesign(String design) {
		this.design = design;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
}

