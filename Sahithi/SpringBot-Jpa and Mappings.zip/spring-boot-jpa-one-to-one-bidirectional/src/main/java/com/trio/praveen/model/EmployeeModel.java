package com.trio.praveen.model;




public class EmployeeModel
{
	private Integer id;
	private String name;
	private String emailId;
	private String mobNo;
	private String design;
	private String street;
	private String city;
	private String state;
	public Integer getId()
	{
		return id;
	}
	public void setId(Integer id) 
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo)
	{
		this.mobNo = mobNo;
	}
	public String getDesign() 
	{
		return design;
	}
	public void setDesign(String design) {
		this.design = design;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) 
	{
		this.street = street;
	}
	public String getCity() 
	{
		return city;
	}
	public void setCity(String city) 
	{
		this.city = city;
	}
	public String getState()
	{
		return state;
	}
	public void setState(String state)
	{
		this.state = state;
	}
	
}
/*
PagingAndSorting is the repository given by spring boot with the followig parameters

1) Offset -> Starting index of the page number 2) Size -> Page size (number of records) need

to be rendered) 3) sortOrder -> Order of Sorting i.e, ASC or DESC

4) SortColumn -> On which column Name we need to achieve Sorting.

Note: Only one column is allowed for sorting.

Example: service.findByLastName("<lastName",0,10,Sort.ASC, "lastName") -> With this we are going to get top 10 records with given last Name with Ascending order of
*/