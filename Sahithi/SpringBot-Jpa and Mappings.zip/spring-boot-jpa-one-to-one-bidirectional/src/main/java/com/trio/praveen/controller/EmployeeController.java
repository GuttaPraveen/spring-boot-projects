package com.trio.praveen.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trio.praveen.entity.Address;
import com.trio.praveen.entity.Employee;
import com.trio.praveen.model.EmployeeModel;
import com.trio.praveen.service.AddressService;
import com.trio.praveen.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController
{
	
	@Autowired
	 AddressService addressService;
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping("/save")
	public ResponseEntity< ? > saveEmp(@RequestBody EmployeeModel empModel)
	{
	    Map< String, Object > model = new LinkedHashMap< String, Object > ();
	    
	    //creating address object and setting properties
	    Address address = new Address();
	    address.setStreet(empModel.getStreet());
	    address.setCity(empModel.getCity());
	    address.setState(empModel.getState());
	    
	    //creating employee object and setting properties
	    Employee emp = new Employee();
	    emp.setName(empModel.getName());
	    emp.setEmailId(empModel.getEmailId());
	    emp.setMobNo(empModel.getMobNo());
	    emp.setDesign(empModel.getDesign());
	    emp.setAddress(address);
	    
	    //saving employee into db
	    employeeService.save(emp);
	    model.put("status", 1);
	    model.put("message", "Record is Saved Successfully!");
	    return new ResponseEntity < > (model, HttpStatus.CREATED);
	  }
	
	  @GetMapping("/employees")
	  public ResponseEntity < ? > getEmployees()
	  {
	    Map < String, Object > model = new LinkedHashMap < String, Object > ();
	    List< Employee > empList = employeeService.findAll();
	    List<EmployeeModel > empMList = new ArrayList < > ();
	    if (!empList.isEmpty()) {
	      for (Employee emp: empList)
	      {
		    	EmployeeModel empModel = new EmployeeModel();
		        empModel.setId(emp.getId());
		        empModel.setName(emp.getName());
		        empModel.setEmailId(emp.getEmailId());
		        empModel.setMobNo(emp.getMobNo());
		        empModel.setDesign(emp.getDesign());
		        empModel.setStreet(emp.getAddress().getStreet());
		        empModel.setCity(emp.getAddress().getCity());
		        empModel.setState(emp.getAddress().getState());
		        empMList.add(empModel);
	      }
	      model.put("status", 1);
	      model.put("data", empMList);
	      return new ResponseEntity < > (model, HttpStatus.OK);
	    } else {
	      model.clear();
	      model.put("status", 0);
	      model.put("message", "Data is not found");
	      return new ResponseEntity < > (model, HttpStatus.NOT_FOUND);
	    }
	  }
	  @GetMapping("/address-list")
	  public ResponseEntity < ? > getAddressList() {
	    Map < String, Object > model = new LinkedHashMap < String, Object > ();
	    List < Address > addList = addressService.findAll();
	    List < EmployeeModel > empMList = new ArrayList < > ();
	    if (!addList.isEmpty())
	    {
		      for (Address address: addList) 
		      {
		    	  EmployeeModel empModel = new EmployeeModel();
		        empModel.setId(address.getEmployee().getId());
		        empModel.setName(address.getEmployee().getName());
		        empModel.setEmailId(address.getEmployee().getEmailId());
		        empModel.setMobNo(address.getEmployee().getMobNo());
		        empModel.setDesign(address.getEmployee().getDesign());
		        empModel.setStreet(address.getStreet());
		        empModel.setCity(address.getCity());
		        empModel.setState(address.getState());
		        empMList.add(empModel);
		      }
		      model.put("status", 1);
		      model.put("data", empMList);
		      return new ResponseEntity < > (model, HttpStatus.OK);
	    }
	    else
	    {
	      model.clear();
	      model.put("status", 0);
	      model.put("message", "Data is not found");
	      return new ResponseEntity < > (model, HttpStatus.NOT_FOUND);
	    }
	  }
}
