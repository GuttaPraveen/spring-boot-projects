package com.trio.praveen.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trio.praveen.entity.Employee;
@Service
public interface EmployeeService
{
	void save(Employee employee);
	List<Employee> findAll();
}
