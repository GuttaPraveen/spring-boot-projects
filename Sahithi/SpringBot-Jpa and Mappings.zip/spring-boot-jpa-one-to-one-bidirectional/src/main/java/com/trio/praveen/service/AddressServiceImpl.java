package com.trio.praveen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trio.praveen.entity.Address;
import com.trio.praveen.repository.AddressRepository;
@Service
public class AddressServiceImpl implements AddressService
{
	@Autowired
	AddressRepository addressRepository;
	@Override
	public void save(Address address)
	{
		// TODO Auto-generated method stub
		addressRepository.save(address);
	}

	@Override
	public List<Address> findAll()
	{
		// TODO Auto-generated method stub
		return addressRepository.findAll();
	}

}
